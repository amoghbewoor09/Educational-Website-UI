let videoList = document.querySelectorAll('.video-list-container .list');

videoList.forEach(vid =>{
   vid.onclick = () =>{
      videoList.forEach(remove =>{remove.classList.remove('active')});
      vid.classList.add('active');
      let src = vid.querySelector('.list-video').src;
      let title = vid.querySelector('.list-title').innerHTML;
      document.querySelector('.main-video-container .main-video').src = src;
      document.querySelector('.main-video-container .main-video').play();
      document.querySelector('.main-video-container .main-vid-title').innerHTML = title;
   };
});




// select video elements and progress bar
const videos = document.querySelectorAll('video');
const progressBar = document.querySelector('.progress-bar');

// calculate total duration of all videos
let totalDuration = 0;
videos.forEach(video => {
   totalDuration += video.duration;
});

// initialize progress variables
let currentVideoIndex = 0;
let currentVideoTime = 0;
let progress = 0;

// add event listeners to videos to update progress bar
videos.forEach(video => {
   video.addEventListener('timeupdate', () => {
      currentVideoTime = 0;
      for (let i = 0; i < currentVideoIndex; i++) {
         currentVideoTime += videos[i].duration;
      }
      currentVideoTime += video.currentTime;
      progress = (currentVideoTime / totalDuration) * 100;
      progressBar.style.width = `${progress}%`;
   });
   video.addEventListener('ended', () => {
      currentVideoIndex++;
      if (currentVideoIndex < videos.length) {
         videos[currentVideoIndex].play();
      }
   });
});

// start playing first video
videos[0].play();
